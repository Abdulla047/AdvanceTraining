package com.assignment7;

class NameNotValidException_7_2_4 extends Exception
{
     public String validname()
     {
          return ("Name is not Valid..Please ReEnter the Name");
     }
}