package com.assignment6;

import java.util.Vector;

public class TestEmployee_6_3_2 {
	
	private static final Employee_6_3_1[] v = null;
	public static void main(String[] args) {
		Vector<Employee_6_3_1> v= addInput();
		display(v);
	}
	private static Vector<Employee_6_3_1> addInput() {
		
		return null;
	}
	private static void display(Vector<Employee_6_3_1> v) {
		
	}
	
	public static Vector<Employee_6_3_1> main1() {
		
		Employee_6_3_1 e1=new Employee_6_3_1(101, "nagesh", "ganesh");
		Employee_6_3_1 e2=new Employee_6_3_1(102, "nichitha", "gopal");
		Employee_6_3_1 e3=new Employee_6_3_1(103, "mallesh", "mahesh");
		Vector<Employee_6_3_1> v=new Vector<Employee_6_3_1>();
		v.add(e1);
		v.add(e2);
		v.add(e3);
		return v;
		
	}
	public static void main2(String[] args) {
		
		for (Employee_6_3_1 e :v) {
			System.out.println(e.getEmpid()+"\t"+e.getEname()+"\t"+e.getAddress());
			
		}
	}
}
