package com.assignment2;

public class IntegerArray_2_3 {  
    public static void main(String[] args) {  
        //Initialize array  
        int [] arr = new int [] {3,2,4,5,6,4,5,7,3,2,3,4,7,1,2,0,0,0};  
        int sum = 0, avg = 0, larg=arr[0];  
        //Loop through the array to calculate sum of elements  
        for (int i = 0; i < arr.length-3; i++) {  
           sum = sum + arr[i];  
           avg = sum/2;
           if(larg>arr[i]) {
        	   larg=arr[i];
           }
        }  
        arr[15]=sum;
        arr[16]=avg;
        arr[17]=larg;
        for(int v:arr) {
        	
        System.out.print(" "+ v);  
        }
    }  
}

	
