package com.assignment3;

public class Piano_3_1_4 extends Instrument_3_1_1 {

	@Override
	public void play() {
		System.out.println("Piano is playing  tan tan tan tan");

	}

}
