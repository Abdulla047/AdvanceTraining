package com.assignment3;

public abstract class Instrument_3_1_1 {
	public abstract void play();
}
