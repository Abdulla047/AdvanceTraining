package com.assignment3;

public class medicine_3_2_1{public void displayLabel(){System.out.println("Company : Globex Pharma");System.out.println("Address : Bangalore");}}class Tablet extends medicine_3_2_1{
	 
public void displayLabel(){System.out.println("store in a cool dry place");}}class Syrup extends medicine_3_2_1{public void displayLabel(){System.out.println("Consumption as directed by thephysician");}}class Ointment extends medicine_3_2_1{public void displayLabel(){System.out.println("for external use only");}}