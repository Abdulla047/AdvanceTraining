package com.assignment3;

public class Flute_3_1_3 extends Instrument_3_1_1 {

	@Override
	public void play() {
		System.out.println("Flute is playing  toot toot toot toot");

	}

}